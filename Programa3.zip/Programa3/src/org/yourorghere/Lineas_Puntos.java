package org.yourorghere;
import com.sun.opengl.util.Animator;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.glu.GLU;
import javax.swing.JFrame;


public class Lineas_Puntos extends JFrame {

    static GL gl;
    static GLU glu;

    public Lineas_Puntos(){
        setTitle("Clase 2 de JOGL");
        setSize(2000,2700);
        
        GraphicListener listener = new GraphicListener();
       
        GLCanvas canvas = new GLCanvas(new GLCapabilities());
        canvas.addGLEventListener(listener);
        getContentPane().add(canvas);
    }

    public static void main (String args[]){
        Lineas_Puntos frame = new Lineas_Puntos();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public class GraphicListener implements GLEventListener{

        public void display(GLAutoDrawable arg0) {
            gl.glLineWidth(5);
            gl.glBegin(GL.GL_LINES);
            gl.glColor3f(1,1,1);

		  //1
                  gl.glColor3f(1.0f, 1.0f, 1.0f);
		  gl.glVertex2f(2.0f,135.0f);
		  gl.glVertex2f(189.0f,135.0f);
                  
		  gl.glVertex2f(2.0f,5.0f);
		  gl.glVertex2f(189.0f,5.0f);
                  
                   gl.glVertex2f(2.0f,135.0f);
		   gl.glVertex2f(2.0f,5.0f);
                   
                   gl.glVertex2f(189.0f,5.0f);
		   gl.glVertex2f(189.0f,135.0f);
                   
                  //2
                  gl.glColor3f(1.0f, 0.0f, 1.0f);
		  gl.glVertex2f(7.0f,130.0f);
		  gl.glVertex2f(184.0f,130.0f);
                  
		  gl.glVertex2f(7.0f,10.0f);
		  gl.glVertex2f(184.0f,10.0f);
                  
                   gl.glVertex2f(7.0f,130.0f);
		   gl.glVertex2f(7.0f,10.0f);
                   
                   gl.glVertex2f(184.0f,10.0f);
		   gl.glVertex2f(184.0f,130.0f);

                    //3
                  gl.glColor3f(0.0f, 0.5f, 1.0f);
		  gl.glVertex2f(12.0f,125.0f);
		  gl.glVertex2f(179.0f,125.0f);
                  
		  gl.glVertex2f(12.0f,15.0f);
		  gl.glVertex2f(179.0f,15.0f);
                  
                   gl.glVertex2f(12.0f,125.0f);
		   gl.glVertex2f(12.0f,15.0f);
                   
                   gl.glVertex2f(179.0f,15.0f);
		   gl.glVertex2f(179.0f,125.0f);
                   
                   //4
                  gl.glColor3f(1.0f, 0.0f, 0.0f);
		  gl.glVertex2f(17.0f,120.0f);
		  gl.glVertex2f(174.0f,120.0f);
                  
		  gl.glVertex2f(17.0f,20.0f);
		  gl.glVertex2f(174.0f,20.0f);
                  
                   gl.glVertex2f(17.0f,120.0f);
		   gl.glVertex2f(17.0f,20.0f);
                   
                   gl.glVertex2f(174.0f,20.0f);
		   gl.glVertex2f(174.0f,120.0f);
                   
                   
                   //5
                  gl.glColor3f(1.0f, 0.5f, 0.0f);
		  gl.glVertex2f(22.0f,115.0f);
		  gl.glVertex2f(169.0f,115.0f);
                  
		  gl.glVertex2f(22.0f,25.0f);
		  gl.glVertex2f(169.0f,25.0f);
                  
                   gl.glVertex2f(22.0f,115.0f);
		   gl.glVertex2f(22.0f,25.0f);
                   
                   gl.glVertex2f(169.0f,25.0f);
		   gl.glVertex2f(169.0f,115.0f);
                   
                   //6
                  gl.glColor3f(1.0f, 1.0f, 0.0f);
		  gl.glVertex2f(27.0f,110.0f);
		  gl.glVertex2f(164.0f,110.0f);
                  
		  gl.glVertex2f(27.0f,30.0f);
		  gl.glVertex2f(164.0f,30.0f);
                  
                   gl.glVertex2f(27.0f,110.0f);
		   gl.glVertex2f(27.0f,30.0f);
                   
                   gl.glVertex2f(164.0f,30.0f);
		   gl.glVertex2f(164.0f,110.0f);
                   
                   //7
                  gl.glColor3f(0.0f, 1.0f, 0.0f);
		  gl.glVertex2f(32.0f,105.0f);
		  gl.glVertex2f(159.0f,105.0f);
                  
		  gl.glVertex2f(32.0f,35.0f);
		  gl.glVertex2f(159.0f,35.0f);
                  
                   gl.glVertex2f(32.0f,105.0f);
		   gl.glVertex2f(32.0f,35.0f);
                   
                   gl.glVertex2f(159.0f,35.0f);
		   gl.glVertex2f(159.0f,105.0f);
                   
                   //8
                  gl.glColor3f(0.0f, 1.0f, 1.0f);
		  gl.glVertex2f(37.0f,100.0f);
		  gl.glVertex2f(154.0f,100.0f);
                  
		  gl.glVertex2f(37.0f,40.0f);
		  gl.glVertex2f(154.0f,40.0f);
                  
                   gl.glVertex2f(37.0f,100.0f);
		   gl.glVertex2f(37.0f,40.0f);
                   
                   gl.glVertex2f(154.0f,40.0f);
		   gl.glVertex2f(154.0f,100.0f);
                   
                   //9
                  gl.glColor3f(2.0f, 0.5f, 1.0f);
		  gl.glVertex2f(42.0f,95.0f);
		  gl.glVertex2f(149.0f,95.0f);
                  
		  gl.glVertex2f(42.0f,45.0f);
		  gl.glVertex2f(149.0f,45.0f);
                  
                   gl.glVertex2f(42.0f,95.0f);
		   gl.glVertex2f(42.0f,45.0f);
                   
                   gl.glVertex2f(149.0f,45.0f);
		   gl.glVertex2f(149.0f,95.0f);
                   
                   
		 
                  gl.glEnd();

                  gl.glFlush();

        }

        public void init(GLAutoDrawable arg0) {
            glu = new GLU();
            gl = arg0.getGL();
            gl.glClearColor(0, 0, 0, 0);
            gl.glMatrixMode(gl.GL_PROJECTION);
            glu.gluOrtho2D(0, 200, 0, 150);
        }

        public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {

        }

        public void displayChanged(GLAutoDrawable drawable, boolean modeChanged, boolean deviceChanged) {

        }

    }


}
